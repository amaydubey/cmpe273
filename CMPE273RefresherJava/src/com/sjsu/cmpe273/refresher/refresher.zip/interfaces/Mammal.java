/**
 * 
 */
package com.sjsu.cmpe273.refresher.interfaces;

/**
 * @author amay
 *
 */
public interface Mammal {
	
	public void eat();
	public void sleep();
	public int noOfLimbs();

}
